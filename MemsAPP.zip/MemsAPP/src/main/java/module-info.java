module com.example.memsapp {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;
    requires com.google.gson;

    opens com.example.memsapp to javafx.fxml;
    //opens com.example.memsapp to  com.google.gson;
    exports com.example.memsapp;
}