package com.example.memsapp;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.util.List;

public class MemeController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        List<Meme> memes = ImgflipApiClientUtils.fetchMemes();
        for (Meme meme : memes) {
            System.out.println(meme.getNameUrl());
        }
        welcomeText.setText("Welcome to Meme Application! Please see conslole to read memes");
    }
}