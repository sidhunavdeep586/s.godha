package com.example.memsapp;

import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.List;

public class ImgflipApiClientUtils {
    private static final ImgflipApiClient imgflipApiClient = new ImgflipApiClient();

    public static List<Meme> fetchMemes() {
        List<Meme> memes = new ArrayList<>();
        String responseData = imgflipApiClient.fetchDataFromApi();

        if (responseData != null && !responseData.isEmpty()) {
            Gson gson = new Gson();
            ImgflipApiResponse response = gson.fromJson(responseData, ImgflipApiResponse.class);

            if (response != null && response.isSuccess() && response.getData() != null) {
                memes.addAll(response.getData().getMemes());
            }
        }

        return memes;
    }
}
