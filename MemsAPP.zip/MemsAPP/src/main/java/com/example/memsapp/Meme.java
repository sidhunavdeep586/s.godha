package com.example.memsapp;
import com.google.gson.annotations.SerializedName;

public class Meme {
    @SerializedName("id")
    public String id;

    @SerializedName("name")
    public String name;

    @SerializedName("url")
    public String url;

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }
    public String getNameUrl(){
        return "Name: "+getName()+"Url: "+getUrl();
    }
}
