package com.example.memsapp;

import java.util.List;

public class ImgflipApiResponse {
    public boolean success;
    public ImgflipData data;

    public boolean isSuccess() {
        return success;
    }

    public ImgflipData getData() {
        return data;
    }
}



