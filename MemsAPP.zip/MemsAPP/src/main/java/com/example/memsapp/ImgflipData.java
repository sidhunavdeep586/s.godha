package com.example.memsapp;

import java.util.List;

public class ImgflipData {
    public List<Meme> memes;

    public List<Meme> getMemes() {
        return memes;
    }
}
